var searchData=
[
  ['functiontype',['FunctionType',['../classkudu_1_1client_1_1KuduLoggingFunctionCallback.html#a98d1aaa700982691ec6ceedd87498f4b',1,'kudu::client::KuduLoggingFunctionCallback::FunctionType()'],['../classkudu_1_1client_1_1KuduStatusFunctionCallback.html#ac175e6c42840c7a0dfbde3d71beac394',1,'kudu::client::KuduStatusFunctionCallback::FunctionType()']]]
];
