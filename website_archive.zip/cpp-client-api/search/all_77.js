var searchData=
[
  ['wait',['wait',['../classkudu_1_1client_1_1KuduTableCreator.html#a48f9e977356c37666106f303100198d9',1,'kudu::client::KuduTableCreator::wait()'],['../classkudu_1_1client_1_1KuduTableAlterer.html#a86e6d55d0888d4bc99789b1dcd0e5646',1,'kudu::client::KuduTableAlterer::wait()']]],
  ['was_5fpossibly_5fsuccessful',['was_possibly_successful',['../classkudu_1_1client_1_1KuduError.html#a178b3cee942e4fbbe21fef859c8da3aa',1,'kudu::client::KuduError']]]
];
