var searchData=
[
  ['membertype',['MemberType',['../classkudu_1_1client_1_1KuduLoggingMemberCallback.html#a5b9d3ed4c111163156a4836152c05afd',1,'kudu::client::KuduLoggingMemberCallback::MemberType()'],['../classkudu_1_1client_1_1KuduStatusMemberCallback.html#a260174e9be807a51fb050c58b047fbdf',1,'kudu::client::KuduStatusMemberCallback::MemberType()']]]
];
