var searchData=
[
  ['datatype',['DataType',['../classkudu_1_1client_1_1KuduColumnSchema.html#aba69238e70af5c887a4fb11fa2a120c5',1,'kudu::client::KuduColumnSchema']]]
];
