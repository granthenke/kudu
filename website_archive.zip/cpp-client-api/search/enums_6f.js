var searchData=
[
  ['ordermode',['OrderMode',['../classkudu_1_1client_1_1KuduScanner.html#a3d6c79325c9da9741d0accf1b43bf7f9',1,'kudu::client::KuduScanner']]]
];
