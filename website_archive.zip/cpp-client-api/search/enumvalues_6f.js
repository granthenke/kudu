var searchData=
[
  ['ordered',['ORDERED',['../classkudu_1_1client_1_1KuduScanner.html#a3d6c79325c9da9741d0accf1b43bf7f9a4395ad2ec57ce53e30d8b5748fa2c63a',1,'kudu::client::KuduScanner']]]
];
