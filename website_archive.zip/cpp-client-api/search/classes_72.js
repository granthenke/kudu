var searchData=
[
  ['resourcemetrics',['ResourceMetrics',['../classkudu_1_1client_1_1ResourceMetrics.html',1,'kudu::client']]]
];
