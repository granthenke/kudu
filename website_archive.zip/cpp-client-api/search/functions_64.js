var searchData=
[
  ['data',['data',['../classkudu_1_1Slice.html#a2d90a4590b995fb55229d25effb0c5bb',1,'kudu::Slice']]],
  ['datatypetostring',['DataTypeToString',['../classkudu_1_1client_1_1KuduColumnSchema.html#af362af4f9c937c2b7fa90ef284cfbd1c',1,'kudu::client::KuduColumnSchema']]],
  ['default',['Default',['../classkudu_1_1client_1_1KuduColumnSpec.html#a92c63c0e1872c03fcabeac19d802f6c7',1,'kudu::client::KuduColumnSpec']]],
  ['default_5fadmin_5foperation_5ftimeout',['default_admin_operation_timeout',['../classkudu_1_1client_1_1KuduClientBuilder.html#a6114bb56e4d9d1231df0ef73c9aec752',1,'kudu::client::KuduClientBuilder::default_admin_operation_timeout()'],['../classkudu_1_1client_1_1KuduClient.html#aacfcd61c7cc1bf7817d1aa0bb738414f',1,'kudu::client::KuduClient::default_admin_operation_timeout()']]],
  ['default_5frpc_5ftimeout',['default_rpc_timeout',['../classkudu_1_1client_1_1KuduClientBuilder.html#a1813e8c8d24e92a0a710724000e2b3df',1,'kudu::client::KuduClientBuilder::default_rpc_timeout()'],['../classkudu_1_1client_1_1KuduClient.html#a2d0e8397e979e651a23eb240513a5556',1,'kudu::client::KuduClient::default_rpc_timeout()']]],
  ['deletetable',['DeleteTable',['../classkudu_1_1client_1_1KuduClient.html#a9d7cbad036bc74c71873a428abce5c1d',1,'kudu::client::KuduClient']]],
  ['deserializeintoscanner',['DeserializeIntoScanner',['../classkudu_1_1client_1_1KuduScanToken.html#ae90d9422476cf6eee5c33afb41d1f867',1,'kudu::client::KuduScanToken']]],
  ['direct_5fdata',['direct_data',['../classkudu_1_1client_1_1KuduScanBatch.html#a1073a0c6517b126690d99527556dba51',1,'kudu::client::KuduScanBatch']]],
  ['dropcolumn',['DropColumn',['../classkudu_1_1client_1_1KuduTableAlterer.html#ac5a4ec376ec53ba912b85ea0057d10a7',1,'kudu::client::KuduTableAlterer']]],
  ['droprangepartition',['DropRangePartition',['../classkudu_1_1client_1_1KuduTableAlterer.html#ab0f8abf78d35725198876aaa04b737a7',1,'kudu::client::KuduTableAlterer']]]
];
