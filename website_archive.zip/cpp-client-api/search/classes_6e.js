var searchData=
[
  ['nulllog',['NullLog',['../classkudu_1_1internal__logging_1_1NullLog.html',1,'kudu::internal_logging']]]
];
