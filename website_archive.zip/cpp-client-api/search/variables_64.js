var searchData=
[
  ['data',['Data',['../classkudu_1_1client_1_1KuduPredicate.html#ae8643ced562f7c8a4625a58a4e39abb0',1,'kudu::client::KuduPredicate']]]
];
