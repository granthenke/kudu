var searchData=
[
  ['comparisonop',['ComparisonOp',['../classkudu_1_1client_1_1KuduPredicate.html#ad58e80ced596d7738f99b5b83ba24eb4',1,'kudu::client::KuduPredicate']]],
  ['compressiontype',['CompressionType',['../classkudu_1_1client_1_1KuduColumnStorageAttributes.html#af579406931a40daa5cb9e10603341a78',1,'kudu::client::KuduColumnStorageAttributes']]]
];
