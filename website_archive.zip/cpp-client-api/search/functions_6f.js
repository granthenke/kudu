var searchData=
[
  ['ok',['OK',['../classkudu_1_1Status.html#adaff3248b2f66041d0a7dd59f118b7ac',1,'kudu::Status::OK()'],['../classkudu_1_1Status.html#abf6454dcb72bfa92189a0595b5a858a7',1,'kudu::Status::ok() const ']]],
  ['open',['Open',['../classkudu_1_1client_1_1KuduScanner.html#aa1ff3c11d9ac9f8183189ea5ac1ed9f1',1,'kudu::client::KuduScanner']]],
  ['opentable',['OpenTable',['../classkudu_1_1client_1_1KuduClient.html#aa82a09718ffe68d3255195e736aec8d7',1,'kudu::client::KuduClient']]],
  ['operator_21_3d',['operator!=',['../classkudu_1_1client_1_1KuduScanBatch.html#afd2b2c4cb038cbd366c2af8cf09a3a68',1,'kudu::client::KuduScanBatch']]],
  ['operator_28_29',['operator()',['../structkudu_1_1Slice_1_1Comparator.html#a2f33c829e2febd880f9cbcbebb08fa6a',1,'kudu::Slice::Comparator']]],
  ['operator_2a',['operator*',['../classkudu_1_1client_1_1KuduScanBatch.html#ab057b7b1bfb713a7e8f216e3b288cb10',1,'kudu::client::KuduScanBatch']]],
  ['operator_2b_2b',['operator++',['../classkudu_1_1client_1_1KuduScanBatch.html#ad5df483ed3172caab5a8d6a72abfad0c',1,'kudu::client::KuduScanBatch::operator++()'],['../classkudu_1_1client_1_1KuduScanBatch.html#a4b1ad47fd7d429859b6181825a063c48',1,'kudu::client::KuduScanBatch::operator++(int)']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classkudu_1_1internal__logging_1_1NullLog.html#abe50abde8e4af12413c99f437094dc8a',1,'kudu::internal_logging::NullLog::operator&lt;&lt;()'],['../classkudu_1_1internal__logging_1_1CerrLog.html#a9febb74005a76f9b203e9718275ab724',1,'kudu::internal_logging::CerrLog::operator&lt;&lt;()']]],
  ['operator_3d',['operator=',['../classkudu_1_1client_1_1KuduColumnSchema.html#a4b58da787c8e7dc14987aa74a54f199e',1,'kudu::client::KuduColumnSchema::operator=()'],['../classKuduPartialRow.html#a03cab3e1aa0bef19c14f94181934181f',1,'KuduPartialRow::operator=()'],['../classkudu_1_1Status.html#aa387797d8a80892563d56244a2351a88',1,'kudu::Status::operator=()']]],
  ['operator_3d_3d',['operator==',['../classkudu_1_1client_1_1KuduScanBatch.html#a378a5844a4b4774056b26f0003c15048',1,'kudu::client::KuduScanBatch']]],
  ['operator_5b_5d',['operator[]',['../classkudu_1_1Slice.html#a5ff06bc0fd9734536a464e604ec226f2',1,'kudu::Slice']]]
];
