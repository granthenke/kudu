var searchData=
[
  ['unordered',['UNORDERED',['../classkudu_1_1client_1_1KuduScanner.html#a3d6c79325c9da9741d0accf1b43bf7f9adfeea547de613f36a0aff9f585671ec3',1,'kudu::client::KuduScanner']]],
  ['unset',['Unset',['../classKuduPartialRow.html#adccabf294832ba33fce80a72992f6e23',1,'KuduPartialRow::Unset(const Slice &amp;col_name) WARN_UNUSED_RESULT'],['../classKuduPartialRow.html#a8f65b552d35d23e6fc494cb1f6dcd394',1,'KuduPartialRow::Unset(int col_idx) WARN_UNUSED_RESULT']]],
  ['uuid',['uuid',['../classkudu_1_1client_1_1KuduTabletServer.html#aacee61a6644f332b466718df00903137',1,'kudu::client::KuduTabletServer']]]
];
