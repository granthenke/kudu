var searchData=
[
  ['type',['type',['../structkudu_1_1SliceMap.html#ac97e49d0aa50ae49f34ab3bbd95ea5e6',1,'kudu::SliceMap']]]
];
