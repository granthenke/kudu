var searchData=
[
  ['release_5ffailed_5fop',['release_failed_op',['../classkudu_1_1client_1_1KuduError.html#ae1a49bd16eeff4d2ab88fa70e1dc3c6a',1,'kudu::client::KuduError']]],
  ['relocate',['relocate',['../classkudu_1_1Slice.html#a4bb1c9fe13873623b5a5a118830b1806',1,'kudu::Slice']]],
  ['remove_5fprefix',['remove_prefix',['../classkudu_1_1Slice.html#a00f5d310f9ebf17c198cf3feb69c3842',1,'kudu::Slice']]],
  ['renameto',['RenameTo',['../classkudu_1_1client_1_1KuduTableAlterer.html#aca8ea8d7b65e6952c76fd97f12d5b324',1,'kudu::client::KuduTableAlterer::RenameTo()'],['../classkudu_1_1client_1_1KuduColumnSpec.html#abeb2cbbaa01253165202574db03872f4',1,'kudu::client::KuduColumnSpec::RenameTo()']]],
  ['replicas',['replicas',['../classkudu_1_1client_1_1KuduTablet.html#a7816ea063549347b676fc18dfa297619',1,'kudu::client::KuduTablet']]],
  ['reset',['Reset',['../classkudu_1_1client_1_1KuduSchema.html#a3f51ccf1a7e6f4a4fe4958073305dbab',1,'kudu::client::KuduSchema']]],
  ['row',['row',['../classkudu_1_1client_1_1KuduWriteOperation.html#a973b342ced786b23754b57fd83b34aa3',1,'kudu::client::KuduWriteOperation::row()'],['../classkudu_1_1client_1_1KuduScanBatch.html#a93c2f0914140dd405a51d57e2f75014a',1,'kudu::client::KuduScanBatch::Row()']]],
  ['rowptr',['RowPtr',['../classkudu_1_1client_1_1KuduScanBatch.html#a92bbfa48e9b503181c2dfb5f11f14e4e',1,'kudu::client::KuduScanBatch']]],
  ['run',['Run',['../classkudu_1_1client_1_1KuduLoggingCallback.html#ad9d5ac9b45246c5a4304d53ee86102eb',1,'kudu::client::KuduLoggingCallback::Run()'],['../classkudu_1_1client_1_1KuduLoggingMemberCallback.html#a3d75e43bb4af846af66735fabe642a88',1,'kudu::client::KuduLoggingMemberCallback::Run()'],['../classkudu_1_1client_1_1KuduLoggingFunctionCallback.html#ab5119cbc60675f3ca77e08c1e87ec215',1,'kudu::client::KuduLoggingFunctionCallback::Run()'],['../classkudu_1_1client_1_1KuduStatusCallback.html#a2333beedb1d0c08a8c127b4552fbeb07',1,'kudu::client::KuduStatusCallback::Run()'],['../classkudu_1_1client_1_1KuduStatusMemberCallback.html#a94bde1bdcb3cde6f78b11d822be19232',1,'kudu::client::KuduStatusMemberCallback::Run()'],['../classkudu_1_1client_1_1KuduStatusFunctionCallback.html#af4c3e7fbd4fed52bcba220f95a27f70a',1,'kudu::client::KuduStatusFunctionCallback::Run()']]]
];
